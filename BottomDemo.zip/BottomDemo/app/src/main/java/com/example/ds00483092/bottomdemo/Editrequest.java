package com.example.ds00483092.bottomdemo;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;

/**
 * Created by DS00483092 on 21-06-2017.
 */

public class Editrequest extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editrequest);

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.NavBot);

        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(1);
        menuItem.setChecked(true);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.ic_raise:
                        Intent intent0 = new Intent(Editrequest.this, MainActivity.class);
                        startActivity(intent0);
                        break;

                    case R.id.ic_edit:

                        break;

                    case R.id.ic_exist:
                        Intent intent2 = new Intent(Editrequest.this, Exist.class);
                        startActivity(intent2);
                        break;

                    case R.id.ic_view:
                        Intent intent3 = new Intent(Editrequest.this, Viewrequest.class);
                        startActivity(intent3);
                        break;

                    case R.id.ic_help:
                        Intent intent4 = new Intent(Editrequest.this, Help.class);
                        startActivity(intent4);
                        break;

                }
                return false;
            }
        });
    }
}