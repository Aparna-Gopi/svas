package com.example.ds00483092.bottomdemo;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Spinner;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import static com.example.ds00483092.bottomdemo.R.id.view;

public class MainActivity extends AppCompatActivity {


    private int myear;
    private int mmonth;
    private int mday;

    static final int DATE_DIALOG_ID = 999;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        final String[] name = new String[1];
        final String[] no = new String[1];
        final String[] no1 = new String[1];
        final String[] id = new String[1];
        final String[] mob = new String[1];
        final String[] start = new String[1];
        final String[] end = new String[1];
        final String[] manu = new String[1];
        final String[] manu1 = new String[1];

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final ImageView imageView = (ImageView) findViewById(R.id.image);
        //save button
        Button save = (Button) findViewById(R.id.save);

        //raise request details

        final EditText associate_id = (EditText) findViewById(R.id.associate_id);
        final EditText associate_name = (EditText) findViewById(R.id.associate_name);
        final EditText mob_no = (EditText) findViewById(R.id.mob_no);
        final Spinner city = (Spinner) findViewById(R.id.city);
        final Spinner location = (Spinner) findViewById(R.id.location);
        Spinner visitor_type = (Spinner) findViewById(R.id.visitor_type);

        EditText startdate = (EditText) findViewById(R.id.startdate);
        EditText enddate = (EditText) findViewById(R.id.enddate);

        setCurrentDateOnView();
        addListenerOnButton();

        setCurrentDateOnView1();
        addListenerOnButton1();


    public void setCurrentDateOnView() {

        startdate = (EditText) findViewById(R.id.startdate);

        final Calendar c = Calendar.getInstance();
        myear = c.get(Calendar.YEAR);
        mmonth = c.get(Calendar.MONTH);
        mday = c.get(Calendar.DAY_OF_MONTH);

        // set current date into textview
        startdate.setText(new StringBuilder()
                // Month is 0 based, just add 1
                .append(mmonth + 1).append("-").append(mday).append("-").append(myear).append(" "));
    }

    public void addListenerOnButton() {

        startdate = (EditText) findViewById(R.id.startdate);

        startdate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                showDialog(DATE_DIALOG_ID);

            }

        });
    }

    protected Dialog onCreateDialogDialog(int id) {
        switch (id) {
            case DATE_DIALOG_ID:
                // set date picker as current date
                DatePickerDialog _date = new DatePickerDialog(this, datePickerListener, myear, mmonth, mday) {
                    @Override
                    public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        if (year < myear) view.updateDate(myear, mmonth, mday);

                        if (monthOfYear < mmonth && year == myear)
                            view.updateDate(myear, mmonth, mday);

                        if (dayOfMonth < mday && year == myear && monthOfYear == mmonth)
                            view.updateDate(myear, mmonth, mday);

                    }
                };
                return _date;
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener datePickerListener1 = new DatePickerDialog.OnDateSetListener() {

        // when dialog box is closed, below method will be called.
        public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
            myear = selectedYear;
            mmonth = selectedMonth;
            mday = selectedDay;

            // set selected date into textview
            startdate.setText(new StringBuilder().append(mmonth + 1).append("-").append(mday).append("-").append(myear).append(" "));

        }
    };

    public void setCurrentDateOnView1() {

        enddate = (EditText) findViewById(R.id.enddate);

        final Calendar c = Calendar.getInstance();
        myear = c.get(Calendar.YEAR);
        mmonth = c.get(Calendar.MONTH);
        mday = c.get(Calendar.DAY_OF_MONTH);

        // set current date into textview
        enddate.setText(new StringBuilder()
                // Month is 0 based, just add 1
                .append(mmonth + 1).append("-").append(mday).append("-").append(myear).append(" "));
    }

    public void addListenerOnButton1() {

        enddate = (EditText) findViewById(R.id.enddate);

        enddate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                showDialog(DATE_DIALOG_ID);

            }

        });
    }

    @Override
    protected Dialog onCreateDialog(int id1) {
        switch (id1) {
            case DATE_DIALOG_ID:
                // set date picker as current date
                DatePickerDialog _date = new DatePickerDialog(this, datePickerListener, myear, mmonth, mday) {
                    @Override
                    public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        if (year < myear) view.updateDate(myear, mmonth, mday);

                        if (monthOfYear < mmonth && year == myear)
                            view.updateDate(myear, mmonth, mday);

                        if (dayOfMonth < mday && year == myear && monthOfYear == mmonth)
                            view.updateDate(myear, mmonth, mday);

                    }
                };
                return _date;
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {

        // when dialog box is closed, below method will be called.
        public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
            myear = selectedYear;
            mmonth = selectedMonth;
            mday = selectedDay;

            // set selected date into textview
            enddate.setText(new StringBuilder().append(mmonth + 1).append("-").append(mday).append("-").append(myear).append(" "));

        }
    };



    RadioGroup escort = (RadioGroup) findViewById(R.id.escort);


        //visitor details

        Spinner gadgets = (Spinner) findViewById(R.id.gadgets);
        Spinner visitor = (Spinner) findViewById(R.id.visitor);
        final EditText serialno = (EditText) findViewById(R.id.serialno);
        final EditText manuf = (EditText) findViewById(R.id.manuf);


        //gadgets details

        final EditText serialno1 = (EditText) findViewById(R.id.serialno1);
        final EditText manuf1 = (EditText) findViewById(R.id.manuf1);






        ImageButton button1 = (ImageButton) findViewById(R.id.visitorbutton);
        ImageButton button2 = (ImageButton) findViewById(R.id.gadgetsbutton);

        final LinearLayout l1 = (LinearLayout)findViewById(R.id.add_visitor);
        final LinearLayout l2 = (LinearLayout)findViewById(R.id.add_gadgets);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (l1.getVisibility() == View.GONE) {
                    l1.setVisibility(View.VISIBLE);
                } else {
                    l1.setVisibility(View.GONE);
                }
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (l2.getVisibility() == View.GONE) {
                    l2.setVisibility(View.VISIBLE);
                } else {
                    l2.setVisibility(View.GONE);
                }
            }
        });

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.NavBot);

        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(0);
        menuItem.setChecked(true);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.ic_raise:

                        break;

                    case R.id.ic_edit:
                        Intent intent1 = new Intent(MainActivity.this, Editrequest.class);
                        startActivity(intent1);
                        break;

                    case R.id.ic_exist:
                        Intent intent2 = new Intent(MainActivity.this, Exist.class);
                        startActivity(intent2);
                        break;

                    case R.id.ic_view:
                        Intent intent3 = new Intent(MainActivity.this, Viewrequest.class);
                        startActivity(intent3);
                        break;

                    case R.id.ic_help:
                        Intent intent4 = new Intent(MainActivity.this, Help.class);
                        startActivity(intent4);
                        break;

                }
                return false;
            }


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                StringBuffer st=new StringBuffer(100);
                /*st.append(editText).toString();
                st.append(editing).toString();
                st.toString();*/
/*
                String str=st.toString();
*/

                id[0] =associate_id.getText().toString().trim();
                name[0] = associate_name.getText().toString().trim();
                mob[0] = mob_no.getText().toString().trim();
                start[0] = startdate.getText().toString().trim();
                end[0] = enddate.getText().toString().trim();
                no[0] = serialno.getText().toString().trim();
                no1[0] = serialno1.getText().toString().trim();
                manu[0] = manuf.getText().toString().trim();
                manu1[0] = manuf1.getText().toString().trim();


                st.append(id[0]);
                st.append("\n");
                st.append(name[0]);
                st.append("\n");
                st.append(mob[0]);st.append("\n");
                st.append(start[0]);st.append("\n");
                st.append(end[0]);st.append("\n");
                st.append(no[0]);st.append("\n");
                st.append(no1[0]);st.append("\n");
                st.append(manu[0]);st.append("\n");
                st.append(manu1[0]);


                Intent intent = new Intent(MainActivity.this,Viewrequest.class);
                intent.putExtra("details", (CharSequence) st);
                startActivity(intent);



            }
        });



    }


}



